#!/bin/bash

# Claude Code Status Line with Full ANSI Colors and Usage Tracking
# Professional colored status line with comprehensive usage analytics

# Get input JSON data first
input=$(cat)

# Extract status line components
model=$(echo "$input" | jq -r '.model.display_name // "Claude"')
session_id=$(echo "$input" | jq -r '.session_id // ""')
current_dir=$(echo "$input" | jq -r '.workspace.current_dir // "unknown"')
project_dir=$(echo "$input" | jq -r '.workspace.project_dir // ""')
output_style=$(echo "$input" | jq -r '.output_style.name // ""')
version=$(echo "$input" | jq -r '.version // ""')

# Usage tracking - integrated directly for better performance
USAGE_FILE="$HOME/.claude/usage_tracking.json"

# Initialize usage file if it doesn't exist
if [ ! -f "$USAGE_FILE" ]; then
    echo '{"daily": {}, "weekly": {}, "total": 0}' > "$USAGE_FILE"
fi

# Get current date info
TODAY=$(date +%Y-%m-%d)
WEEK=$(date +%Y-W%U)

# Read current usage
current_usage=$(cat "$USAGE_FILE")
daily_count=$(echo "$current_usage" | jq -r ".daily.\"$TODAY\" // 0")
weekly_count=$(echo "$current_usage" | jq -r ".weekly.\"$WEEK\" // 0")
total_count=$(echo "$current_usage" | jq -r ".total // 0")

# Increment counts
new_daily=$((daily_count + 1))
new_weekly=$((weekly_count + 1))
new_total=$((total_count + 1))

# Update usage file
echo "$current_usage" | jq \
    --arg today "$TODAY" \
    --arg week "$WEEK" \
    --argjson daily "$new_daily" \
    --argjson weekly "$new_weekly" \
    --argjson total "$new_total" \
    '.daily[$today] = $daily | .weekly[$week] = $weekly | .total = $total' > "$USAGE_FILE"

# Enhanced git information
branch=$(git branch --show-current 2>/dev/null || echo 'no-git')
git_status=""
if [[ "$branch" != "no-git" ]]; then
    # Check for various git states
    git_changes=""
    if ! git diff --quiet HEAD 2>/dev/null || ! git diff --cached --quiet 2>/dev/null; then
        git_changes="*"
    fi
    
    # Check for unpushed commits
    if git log @{u}.. --oneline 2>/dev/null | grep -q .; then
        git_changes="${git_changes}↑"
    fi
    
    # Check for unpulled commits  
    if git log ..@{u} --oneline 2>/dev/null | grep -q .; then
        git_changes="${git_changes}↓"
    fi
    
    git_status="${git_changes}"
fi

# Enhanced directory display
if [[ -n "$project_dir" && "$current_dir" == "$project_dir"* ]]; then
    dir_display=$(echo "$current_dir" | sed "s|^$project_dir|.|")
    if [[ "$dir_display" == "." ]]; then
        dir_display=$(basename "$project_dir")
    fi
else
    # Show last 2-3 components for better context
    dir_display=$(echo "$current_dir" | awk -F'/' '{
        if (NF <= 2) print $0
        else if (NF == 3) printf "%s/%s/%s", $(NF-2), $(NF-1), $NF  
        else printf ".../%s/%s/%s", $(NF-2), $(NF-1), $NF
    }')
fi

# Build professional colored status line
status_parts=()

# Model (dimmed white/gray - professional and subtle)
status_parts+=("\033[2;37m${model}\033[0m")

# Directory (bright cyan - clear and prominent)
status_parts+=("\033[96m${dir_display}\033[0m")

# Git branch with enhanced color coding
if [[ "$branch" != "no-git" ]]; then
    full_git="${branch}${git_status}"
    if [[ "$git_status" == *"*"* ]]; then
        # Red for uncommitted changes
        status_parts+=("\033[91m${full_git}\033[0m")
    elif [[ "$git_status" == *"↑"* ]] || [[ "$git_status" == *"↓"* ]]; then
        # Yellow for sync issues
        status_parts+=("\033[93m${full_git}\033[0m")
    else
        # Green for clean and synced
        status_parts+=("\033[92m${full_git}\033[0m")
    fi
fi

# Output style (bright green when not default)
if [[ -n "$output_style" && "$output_style" != "null" && "$output_style" != "default" ]]; then
    status_parts+=("\033[92m${output_style}\033[0m")
fi

# Usage stats (dimmed but readable)
status_parts+=("\033[2;37m${new_daily}today\033[0m")
status_parts+=("\033[2;37m${new_weekly}week\033[0m")
status_parts+=("\033[2;37m${new_total}total\033[0m")

# Output with attractive separators
printf "%s" "${status_parts[0]}"
for ((i=1; i<${#status_parts[@]}; i++)); do
    printf " \033[2;90m│\033[0m %s" "${status_parts[i]}"
done
printf "\n"