#!/bin/bash

# Claude Code Status Line Script
# Reads JSON input from stdin and outputs formatted status line

# Debug: Log that script is being executed
echo "Status line script executed at $(date)" >> /home/tchow/.claude/statusline.log 2>&1

# Read JSON input from stdin with timeout to avoid hanging
input=$(timeout 5s cat || echo '{}')

# Debug: Log the input
echo "Input received: $input" >> /home/tchow/.claude/statusline.log 2>&1

# Check if jq is available
if ! command -v jq &> /dev/null; then
    echo "Claude in $(basename "$(pwd)")"
    exit 0
fi

# Extract information using jq
model_display_name=$(echo "$input" | jq -r '.model.display_name // "Claude"' 2>/dev/null || echo "Claude")
current_dir=$(echo "$input" | jq -r '.workspace.current_dir // ""' 2>/dev/null || echo "")
project_dir=$(echo "$input" | jq -r '.workspace.project_dir // ""' 2>/dev/null || echo "")

# Get current directory name (basename of path)
if [ -n "$current_dir" ]; then
    dir_name=$(basename "$current_dir")
else
    dir_name=$(basename "$(pwd)")
fi

# Get git branch if in a git repository
git_branch=""
if [ -n "$current_dir" ] && [ -d "$current_dir/.git" ]; then
    cd "$current_dir" 2>/dev/null && git_branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
elif [ -d "$(pwd)/.git" ]; then
    git_branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
fi

# Format the status line
status_parts=()

# Add model name
status_parts+=("$model_display_name")

# Add directory
if [ -n "$dir_name" ]; then
    status_parts+=("$dir_name")
fi

# Add git branch if available
if [ -n "$git_branch" ]; then
    status_parts+=("($git_branch)")
fi

# Join parts with " in " or " " as separator
if [ ${#status_parts[@]} -eq 1 ]; then
    result="${status_parts[0]}"
elif [ ${#status_parts[@]} -eq 2 ]; then
    result="${status_parts[0]} in ${status_parts[1]}"
else
    # Model in directory (branch)
    result=$(printf "%s in %s %s" "${status_parts[0]}" "${status_parts[1]}" "${status_parts[2]}")
fi

# Debug: Log the result
echo "Result: $result" >> /home/tchow/.claude/statusline.log 2>&1

# Output the result
echo "$result"