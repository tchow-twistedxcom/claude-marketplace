#!/bin/bash
# Skill Forced Eval Hook - Enforces 3-step skill evaluation before implementation
# This hook injects a reminder at prompt submission to force visible skill evaluation

cat << 'EOF'
<user-prompt-submit-hook>
⚠️ SKILL EVALUATION REQUIRED - Before ANY implementation, you MUST complete these 3 visible steps:

📋 SKILL EVALUATION (Step 1/3)
Keywords: [extract from request]
Directories: ~/.claude/plugins/, ~/.claude/skills/
Matches: [list skills or "none"]

🎯 SKILL COMMITMENT (Step 2/3)
- [skill]: YES/NO → [reason]

🔧 PROCEEDING (Step 3/3)
Using: [skill/tool] OR Native capabilities

DO NOT skip these steps. DO NOT say "do this manually" if a skill exists.
</user-prompt-submit-hook>
EOF
