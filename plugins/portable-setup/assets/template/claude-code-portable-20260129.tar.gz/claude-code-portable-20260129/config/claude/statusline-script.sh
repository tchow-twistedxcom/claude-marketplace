#!/bin/bash

# Claude Code Status Line with Advanced Usage Tracking
# This script displays model, directory, git branch, and Anthropic usage statistics

# Read JSON input from stdin
input=$(cat)

# Extract basic information from JSON
model=$(echo "$input" | jq -r '.model.display_name // "Claude"')
current_dir=$(echo "$input" | jq -r '.workspace.current_dir // "unknown"')

# Get git branch with status indicators (suppress errors if not a git repo)
if git rev-parse --git-dir >/dev/null 2>&1; then
    branch=$(git branch --show-current 2>/dev/null || echo 'detached')
    
    # Add git status indicators
    git_status=""
    if [[ -n $(git status --porcelain 2>/dev/null) ]]; then
        git_status="*"  # Uncommitted changes
    fi
    
    if [[ -n $(git log --oneline @{u}.. 2>/dev/null) ]]; then
        git_status="${git_status}↑"  # Unpushed commits
    fi
    
    if [[ -n $(git log --oneline ..@{u} 2>/dev/null) ]]; then
        git_status="${git_status}↓"  # Unpulled commits
    fi
    
    branch="${branch}${git_status}"
else
    branch='no-git'
fi

# Get usage statistics using the advanced usage limiter
usage_data=""
if [[ -f "$HOME/.claude/usage-limiter.sh" ]]; then
    # Pass the complete JSON input to usage-limiter.sh
    if usage_output=$(echo "$input" | bash "$HOME/.claude/usage-limiter.sh" 2>/dev/null); then
        # Parse the returned usage data
        fiveh_percentage=$(echo "$usage_output" | jq -r '.["5_hour_usage"].percentage // 0')
        fiveh_color=$(echo "$usage_output" | jq -r '.["5_hour_usage"].color // "🟢"')
        fiveh_current_cost=$(echo "$usage_output" | jq -r '.["5_hour_usage"].cost.current // 0')
        fiveh_limit_cost=$(echo "$usage_output" | jq -r '.["5_hour_usage"].cost.limit // 2.00')
        
        sevenday_percentage=$(echo "$usage_output" | jq -r '.["7_day_usage"].percentage // 0')
        sevenday_color=$(echo "$usage_output" | jq -r '.["7_day_usage"].color // "🟢"')
        sevenday_current_cost=$(echo "$usage_output" | jq -r '.["7_day_usage"].cost.current // 0')
        sevenday_limit_cost=$(echo "$usage_output" | jq -r '.["7_day_usage"].cost.limit // 20.00')
        
        # Format percentages to 0 decimal places for display
        fiveh_display=$(printf "%.0f" "$fiveh_percentage")
        sevenday_display=$(printf "%.0f" "$sevenday_percentage")
        
        # Build usage string with color indicators and percentages
        usage_data=$(printf " \033[0;90m|\033[0m \033[0;37m5h: %s%s%% (\033[0;32m$%s\033[0;37m/\033[0;32m%s\033[0;37m)\033[0m \033[0;90m|\033[0m \033[0;37mWeek: %s%s%% (\033[0;32m$%s\033[0;37m/\033[0;32m%s\033[0;37m)\033[0m" \
            "$fiveh_color" "$fiveh_display" "$fiveh_current_cost" "$fiveh_limit_cost" \
            "$sevenday_color" "$sevenday_display" "$sevenday_current_cost" "$sevenday_limit_cost")
    else
        # Fallback to simple usage indicator if usage-limiter.sh fails
        usage_data=" \033[0;90m|\033[0m \033[0;37mUsage: \033[0;31mUnavailable\033[0m"
    fi
else
    # Fallback if usage-limiter.sh doesn't exist
    usage_data=" \033[0;90m|\033[0m \033[0;37mUsage: \033[0;31mNot configured\033[0m"
fi

# Display the status line with colors
# Format: Model Directory GitBranch | 5h: 🟢45% ($0.90/2.00) | Week: 🟡72% ($14.40/20.00)
printf "\033[0;36m%s\033[0m \033[0;33m%s\033[0m \033[0;32m%s\033[0m%s" \
    "$model" "$(basename "$current_dir")" "$branch" "$usage_data"