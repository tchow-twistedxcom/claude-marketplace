#!/bin/bash

# Simple Claude Code Status Line Script (no jq dependency)
# Provides basic status information

# Get current directory name
dir_name=$(basename "$(pwd)")

# Get git branch if in a git repository
git_branch=""
if [ -d "$(pwd)/.git" ]; then
    git_branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
fi

# Format output
if [ -n "$git_branch" ]; then
    echo "Claude in $dir_name ($git_branch)"
else
    echo "Claude in $dir_name"
fi